import os
import math
import timm
import torch
import numpy as np
from tqdm import tqdm
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from utils import t2np, get_logp, adjust_learning_rate, warmup_learning_rate, save_results, save_weights, load_weights
from datasets import create_fas_data_loader
from models import positionalencoding2d, load_flow_model
from losses import get_logp_boundary, calculate_bg_spp_loss, normal_fl_weighting, abnormal_fl_weighting
from utils.visualizer import plot_visualizing_results
from utils.utils import MetricRecorder, calculate_pro_metric, convert_to_anomaly_scores, evaluate_thresholds
import joblib
import cv2
from torch.utils.data import Dataset, DataLoader
import random

log_theta = torch.nn.LogSigmoid()

CODE2LABEL = {"A": "normal", "B1": "fighting", "B2": "shooting", "B4": "riot", "B5": "abuse", "B6": "car accident", "G": "explosion"}
LABEL2IDX = {"normal": 0, "fighting": 1, "shooting": 2, "riot": 3, "abuse": 4, "car accident": 5, "explosion": 6}

def extract_labels(video_id):
    """Extracts labels from the video id."""
    codes = video_id.split("_")[-1].split(".mp4")[0].split("-")
    include_anomaly_or_not = 1 if len(codes) > 1 else 0
    multilabel = [
        CODE2LABEL[code] for code in codes if code != "0"
    ]
    return include_anomaly_or_not, multilabel

# Define a custom Dataset
class CustomDataset(Dataset):
    def __init__(self, data_list):
        self.data = data_list
    def __len__(self):
        return len(self.data)
    def __getitem__(self, index):
        return self.data[index]

def train_meta_epoch(args, encoder, decoders, optimizer):
    batch_size = 1024
    N_batch_frames_analyze_together = batch_size
    decoders = [decoder.train() for decoder in decoders]

    # fetch training data
    src_dir = '/path/to/embeddings'
    video_dir = '/path/to/videos'
    all_test_videos_anno = '/path/to/annos'
    # build two libs for normal and abnormal, from all videos
    normal_lib_for_train, abnormal_lib_for_train = [], []
    # normal_lib_for_train: a list of elements each of which is [768*5*5, 1*5*5], the former indicates 25 samples, the latter denotes the normal/abnormal masks of the 25 samples
    # abnormal_lib_for_train: a list of elements each of which is [768*5*5, 1*5*5], the former indicates 25 samples, the latter denotes the normal/abnormal masks of the 25 samples

    # Create a Dataset instance
    dataset_normal = CustomDataset(normal_lib_for_train)
    dataset_all = CustomDataset(normal_lib_for_train + abnormal_lib_for_train)
    train_normal_loader = DataLoader(dataset_normal, batch_size=batch_size, shuffle=True)
    train_all_loader = DataLoader(dataset_all, batch_size=batch_size, shuffle=True)
    I = len([train_normal_loader, train_all_loader])

    if True:
        # start training. First epoch only training on normal samples to keep training steadily
        for epoch in range(args.meta_epochs):
            adjust_learning_rate(args, optimizer, epoch)
            if epoch == 0:
                data_loader = train_normal_loader
            else:
                data_loader = train_all_loader

            for sub_epoch in range(args.sub_epochs):
                total_loss, loss_count = 0.0, 0
                for i, (data) in enumerate(tqdm(data_loader)):
                    # warm-up learning rate
                    lr = warmup_learning_rate(args, epoch, i+sub_epoch*I, I*args.sub_epochs, optimizer)

                    with torch.no_grad():
                        features, mask = data
                    features = [features.to(args.device)]
                    mask = mask.to(args.device)
                    for l in range(args.feature_levels):
                        e = features[l].detach()
                        bs, dim, h, w = e.size()
                        mask_ = F.interpolate(mask, size=(feature_height, feature_width), mode='nearest').squeeze(1)
                        mask_ = mask_.reshape(-1)
                        e = e.permute(0, 2, 3, 1).reshape(-1, dim)

                        # (bs, 128, h, w)
                        pos_embed = positionalencoding2d(args.pos_embed_dim, h, w).to(args.device).unsqueeze(0).repeat(bs, 1, 1, 1)
                        pos_embed = pos_embed.permute(0, 2, 3, 1).reshape(-1, args.pos_embed_dim)
                        decoder = decoders[l]

                        perm = torch.randperm(bs*h*w).to(args.device)
                        num_N_batches = bs*h*w // N_batch_frames_analyze_together
                        for i in range(num_N_batches):
                            idx = torch.arange(i*N_batch_frames_analyze_together, (i+1)*N_batch_frames_analyze_together)
                            p_b = pos_embed[perm[idx]]
                            e_b = e[perm[idx]]
                            m_b = mask_[perm[idx]]
                            if args.flow_arch == 'flow_model':
                                z, log_jac_det = decoder(e_b)
                            else:
                                z, log_jac_det = decoder(e_b, [p_b, ])

                            # first epoch only training normal samples
                            # logps = get_logp(dim, z, log_jac_det)
                            # logps = logps / dim
                            # loss = -log_theta(logps).mean()
                            #
                            # optimizer.zero_grad()
                            # loss.backward()
                            # optimizer.step()
                            # total_loss += loss.item()
                            # loss_count += 1

                            if epoch == 0:
                                if m_b.sum() == 0:  # only normal loss
                                    logps = get_logp(dim, z, log_jac_det)
                                    logps = logps / dim
                                    loss = -log_theta(logps).mean()

                                    optimizer.zero_grad()
                                    loss.backward()
                                    optimizer.step()
                                    total_loss += loss.item()
                                    loss_count += 1
                            else:
                                if m_b.sum() == 0:  # only normal ml loss
                                    logps = get_logp(dim, z, log_jac_det)
                                    logps = logps / dim
                                    if args.focal_weighting:
                                        normal_weights = normal_fl_weighting(logps.detach())
                                        loss = -log_theta(logps) * normal_weights
                                        loss = loss.mean()
                                    else:
                                        loss = -log_theta(logps).mean()
                                if m_b.sum() > 0:  # normal ml loss and bg_sppc loss
                                    logps = get_logp(dim, z, log_jac_det)
                                    logps = logps / dim
                                    if args.focal_weighting:
                                        logps_detach = logps.detach()
                                        normal_logps = logps_detach[m_b == 0]
                                        anomaly_logps = logps_detach[m_b == 1]
                                        nor_weights = normal_fl_weighting(normal_logps)
                                        ano_weights = abnormal_fl_weighting(anomaly_logps)
                                        weights = nor_weights.new_zeros(logps_detach.shape)
                                        weights[m_b == 0] = nor_weights
                                        weights[m_b == 1] = ano_weights
                                        loss_ml = -log_theta(logps[m_b == 0]) * nor_weights + log_theta(logps[m_b == 1]) * ano_weights # (256, )
                                        loss_ml = torch.mean(loss_ml)
                                    else:
                                        loss_ml = -log_theta(logps[m_b == 0]) + log_theta(logps[m_b == 1])
                                        loss_ml = torch.mean(loss_ml)

                                    loss = loss_ml

                                optimizer.zero_grad()
                                loss.backward()
                                optimizer.step()
                                loss_item = loss.item()
                                if math.isnan(loss_item):
                                    total_loss += 0.0
                                    loss_count += 0
                                else:
                                    total_loss += loss.item()
                                    loss_count += 1

                mean_loss = total_loss / loss_count
                print('Epoch: {:d}.{:d} \t train loss: {:.4f}, lr={:.6f}'.format(epoch, sub_epoch, mean_loss, lr))
        save_weights(encoder, decoders, '/path/to/weights.pt')  # avoid unnecessary saves
    else:
        load_weights(encoder, decoders, '/path/to/weights.pt')

    ####################################################### test ###############################################################
    dataset_all_for_test = CustomDataset(normal_lib_for_test + abnormal_lib_for_test)
    test_all_loader = DataLoader(dataset_all_for_test, batch_size=batch_size, shuffle=True)
    logps_list = [list() for _ in range(args.feature_levels)]
    total_loss, loss_count = 0.0, 0
    gt_mask_list = []
    with torch.no_grad():
        for i, (data) in enumerate(tqdm(test_all_loader)):
            features, mask = data
            features = [features.to(args.device)]
            mask = mask.to(args.device)
            gt_mask_list.extend(t2np(mask))
            for l in range(args.feature_levels):
                e = features[l]  # BxCxHxW
                bs, dim, h, w = e.size()
                e = e.permute(0, 2, 3, 1).reshape(-1, dim)

                # (bs, 128, h, w)
                pos_embed = positionalencoding2d(args.pos_embed_dim, h, w).to(args.device).unsqueeze(0).repeat(bs, 1, 1, 1)
                pos_embed = pos_embed.permute(0, 2, 3, 1).reshape(-1, args.pos_embed_dim)
                decoder = decoders[l]

                if args.flow_arch == 'flow_model':
                    z, log_jac_det = decoder(e)
                else:
                    z, log_jac_det = decoder(e, [pos_embed, ])

                logps = get_logp(dim, z, log_jac_det)
                logps = logps / dim
                loss = -log_theta(logps).mean()
                total_loss += loss.item()
                loss_count += 1
                logps_list[l].append(logps.reshape(bs, h, w))

    mean_loss = total_loss / loss_count
    print('Epoch: {:d} \t test_loss: {:.4f}'.format(args.meta_epochs, mean_loss))

    args.img_size = (feature_height, feature_width)
    scores = convert_to_anomaly_scores(args, logps_list)
    # calculate detection AUROC
    img_scores = np.max(scores, axis=(1, 2))
    # calculate segmentation AUROC
    gt_mask = np.squeeze(np.asarray(gt_mask_list, dtype=np.bool), axis=1)
    pix_auc = roc_auc_score(gt_mask.flatten(), scores.flatten())

    return pix_auc

def validate(args, epoch, data_loader, encoder, decoders):
    print('\nCompute loss and scores on category: {}'.format(args.class_name))
    
    decoders = [decoder.eval() for decoder in decoders]
    
    image_list, gt_label_list, gt_mask_list, file_names, img_types = [], [], [], [], []
    logps_list = [list() for _ in range(args.feature_levels)]
    total_loss, loss_count = 0.0, 0
    with torch.no_grad():
        for i, (image, label, mask, file_name, img_type) in enumerate(tqdm(data_loader)):
            # image: (32, 3, 256); label: (32, ); mask: (32, 1, 256, 256)
            if args.vis:
                image_list.extend(t2np(image))
                file_names.extend(file_name)
                img_types.extend(img_type)
            gt_label_list.extend(t2np(label))
            gt_mask_list.extend(t2np(mask))
            
            image = image.to(args.device) # single scale
            features = encoder(image)  # BxCxHxW
            for l in range(args.feature_levels):
                e = features[l]  # BxCxHxW
                bs, dim, h, w = e.size()
                e = e.permute(0, 2, 3, 1).reshape(-1, dim)
               
                # (bs, 128, h, w)
                pos_embed = positionalencoding2d(args.pos_embed_dim, h, w).to(args.device).unsqueeze(0).repeat(bs, 1, 1, 1)
                pos_embed = pos_embed.permute(0, 2, 3, 1).reshape(-1, args.pos_embed_dim)
                decoder = decoders[l]

                if args.flow_arch == 'flow_model':
                    z, log_jac_det = decoder(e)  
                else:
                    z, log_jac_det = decoder(e, [pos_embed, ])

                logps = get_logp(dim, z, log_jac_det)  
                logps = logps / dim  
                loss = -log_theta(logps).mean() 
                total_loss += loss.item()
                loss_count += 1
                logps_list[l].append(logps.reshape(bs, h, w))
    
    mean_loss = total_loss / loss_count
    print('Epoch: {:d} \t test_loss: {:.4f}'.format(epoch, mean_loss))
    
    scores = convert_to_anomaly_scores(args, logps_list)
    # calculate detection AUROC
    img_scores = np.max(scores, axis=(1, 2))
    gt_label = np.asarray(gt_label_list, dtype=np.bool)
    img_auc = roc_auc_score(gt_label, img_scores)
    # calculate segmentation AUROC
    gt_mask = np.squeeze(np.asarray(gt_mask_list, dtype=np.bool), axis=1)
    pix_auc = roc_auc_score(gt_mask.flatten(), scores.flatten())
    #pix_auc = -1
    pix_pro = -1
    if args.pro:
        pix_pro = calculate_pro_metric(scores, gt_mask)
    
    if args.vis and epoch == args.meta_epochs - 1:
        img_threshold, pix_threshold = evaluate_thresholds(gt_label, gt_mask, img_scores, scores)
        save_dir = os.path.join(args.output_dir, args.exp_name, 'vis_results', args.class_name)
        os.makedirs(save_dir, exist_ok=True)
        plot_visualizing_results(image_list, scores, img_scores, gt_mask_list, pix_threshold, 
                                 img_threshold, save_dir, file_names, img_types)

    return img_auc, pix_auc, pix_pro



def train(args):
    # Feature Extractor
    encoder = timm.create_model(args.backbone_arch, features_only=True, 
                out_indices=[i+1 for i in range(args.feature_levels)], pretrained=True)
    encoder = encoder.to(args.device).eval()
    feat_dims = [768]
    args.feature_levels = 1

    # Normalizing Flows
    decoders = [load_flow_model(args, feat_dim) for feat_dim in feat_dims]
    decoders = [decoder.to(args.device) for decoder in decoders]
    params = list(decoders[0].parameters())
    for l in range(1, args.feature_levels):
        params += list(decoders[l].parameters())
    # optimizer
    optimizer = torch.optim.Adam(params, lr=args.lr)
    # data loaders
    normal_loader, train_loader, test_loader = create_fas_data_loader(args)

    # stats
    img_auc_obs = MetricRecorder('IMG_AUROC')
    pix_auc_obs = MetricRecorder('PIX_AUROC')
    pix_pro_obs = MetricRecorder('PIX_AUPRO')
    for epoch in range(args.meta_epochs):
        if args.checkpoint:
            load_weights(encoder, decoders, args.checkpoint)

        print('Train meta epoch: {}'.format(epoch))
        # original
        # train_meta_epoch(args, epoch, [normal_loader, train_loader], encoder, decoders, optimizer)
        # revised
        train_meta_epoch(args, encoder, decoders, optimizer)

        img_auc, pix_auc, pix_pro = validate(args, epoch, test_loader, encoder, decoders)

        img_auc_obs.update(100.0 * img_auc, epoch)
        pix_auc_obs.update(100.0 * pix_auc, epoch)
        pix_pro_obs.update(100.0 * pix_pro, epoch)
        
    if args.save_results:
        save_results(img_auc_obs, pix_auc_obs, pix_pro_obs, args.output_dir, args.exp_name, args.model_path, args.class_name)
        save_weights(encoder, decoders, args.output_dir, args.exp_name, args.model_path)  # avoid unnecessary saves

    return img_auc_obs.max_score, pix_auc_obs.max_score, pix_pro_obs.max_score