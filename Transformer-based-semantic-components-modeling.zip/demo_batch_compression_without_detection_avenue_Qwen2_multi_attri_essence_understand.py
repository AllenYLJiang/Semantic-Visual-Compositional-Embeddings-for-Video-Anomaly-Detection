import collections
import sys
sys.path.insert(0, '/home/vipuser/anaconda3/envs/Qwen2/lib/python3.11/site-packages')
# sys.path.append('/home/vipuser/Downloads/Qwen2-VL-main')
# from transformers import AutoModelForCausalLM, AutoTokenizer
# from transformers import Qwen2VLForConditionalGeneration, AutoTokenizer, AutoProcessor
# from qwen_vl_utils import process_vision_info
import time
import torch
import os
import joblib
import numpy as np
# from transformers.generation import GenerationConfig
torch.manual_seed(1234)
import cv2
from PIL import Image
# from lavis.models import load_model_and_preprocess
import torch.nn.functional as F
import requests
# from transformers import Blip2Processor, Blip2ForConditionalGeneration
import nltk
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
from nltk.corpus import wordnet as wn
from nltk.tokenize.treebank import TreebankWordDetokenizer
nltk.data.path.append('/home/vipuser/Downloads/TIP2024_code')
import json
import re

################################################### Qwen2 part ############################################################################
# default: Load the model on the available device(s)
# model = Qwen2VLForConditionalGeneration.from_pretrained(
#     "/data/Qwen2-VL-7B-Instruct", torch_dtype="auto", device_map="auto"
# )

# default processer
# processor = AutoProcessor.from_pretrained("/data/Qwen2-VL-7B-Instruct")

####################################################### functions ######################################################################
def sliding_window_crop(image, window_size=(224, 224), step_size=(112, 112)):
    """
    Perform sliding window crop on an image with the specified window size and step size.

    :param image: Input image as a NumPy array (e.g., loaded using cv2.imread)
    :param window_size: Tuple (height, width) specifying the size of the crop window
    :param step_size: Tuple (height, width) specifying the step size of the sliding window
    :return: List of cropped images
    """
    crops = []
    img_height, img_width = image.shape[:2]
    window_height, window_width = window_size
    step_height, step_width = step_size

    for y in range(0, img_height - window_height + step_height, step_height):
        for x in range(0, img_width - window_width + step_width, step_width):
            # Adjust the window if it goes beyond the image boundaries
            crop = image[y:min(y + window_height, img_height), x:min(x + window_width, img_width)]
            crops.append(crop)

    return crops

def readfile(filepath):
    if os.path.exists(filepath):
        file = joblib.load(filepath)
    else:
        file = json.load(open(filepath[:-4] + ".json", 'r'))
    return file

################################################ Qwen2 generate sentence for each frame ###########################################
trainval_dir = 'D:\\pyproject\\LAVIS-main\\data\\Shanghaitech\\splits\\shanghaitech\\shanghaitech\\images'
dst_dir = 'G:\\findlet_backup\\shanghaitech\\dump'
json_train_dir = "E:\\pyproject1\\STG-NF\\train"
json_test_dir = "E:\\pyproject1\\STG-NF\\test\\test"

batch_size = 8

for video_name in sorted(os.listdir(trainval_dir), key=lambda x:x.split('.')[0])[:2] + sorted(os.listdir(trainval_dir), key=lambda x:x.split('.')[0]): #sorted(os.listdir(trainval_dir), key=lambda x:x.split('.')[0]):
    print(video_name)
    if video_name[-4:] != '.avi':  # test dataset
        json_pkl_file = readfile(os.path.join(json_test_dir, video_name + ".pkl"))
        frame_list = [re.findall(r'\d+', x["image"])[0] for x in json_pkl_file]
        frame_list = sorted(list(set(frame_list)))
        curr_video_frame_list = sorted(os.listdir(os.path.join(trainval_dir, video_name)), key=lambda x:int(x.split('.')[0]))
        curr_video_num_frames = len(curr_video_frame_list)
    else:  # train dataset
        json_pkl_file = readfile(os.path.join(json_train_dir, video_name.split('.')[0] + ".pkl"))
        frame_list = [int(re.findall(r'\d+', x["image"])[0]) for x in json_pkl_file]
        frame_list = sorted(list(set(frame_list)))
        cap = cv2.VideoCapture(os.path.join(trainval_dir, video_name))
        video_width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        video_height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        curr_video_num_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    curr_video_features = []
    batch_of_messages = []
    curr_video_results = []
    for curr_frame_idx in frame_list: #[54:]:
        print('frame index: ' + str(curr_frame_idx))
        if video_name[-4:] != '.avi':
            curr_frame = cv2.imread(os.path.join(trainval_dir, video_name, "{:03}".format(int(curr_frame_idx)) + ".jpg"))
        else:
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(curr_frame_idx))
            success_or_no, curr_frame = cap.read()
            if success_or_no is False:
                continue
        # crop sliding window
        video_width, video_height, crop_size_height, crop_size_width = curr_frame.shape[1], curr_frame.shape[0], 300, 300
        curr_frame_sliding_window_cropped_regions = sliding_window_crop(curr_frame, window_size=(crop_size_height, crop_size_width), step_size=( int(crop_size_height/2), int(crop_size_width/2) ))
        ################################## detect objects from each sliding window ########################################################
        images, curr_batch_img_cat_list = [], []
        for single_crop_idx in range(len(curr_frame_sliding_window_cropped_regions)):
            if not os.path.exists(os.path.join(dst_dir, video_name.split(".")[0])):
                os.mkdir(os.path.join(dst_dir, video_name.split(".")[0]))
            cv2.imwrite(os.path.join(dst_dir, video_name.split(".")[0]) + "/" + 'Frame_' + str(curr_frame_idx) + 'Crop_' + str(single_crop_idx) + '.jpg', curr_frame_sliding_window_cropped_regions[single_crop_idx])

            # images.append('dump/dump_' + 'Frame_' + str(curr_frame_idx) + 'Crop_' + str(single_crop_idx) + '.jpg')# load sample image
            #
            # messages = [
            #     {
            #         "role": "user",
            #         "content": [
            #             {
            #                 "type": "image",
            #                 "image": 'dump/dump_' + 'Frame_' + str(curr_frame_idx) + 'Crop_' + str(single_crop_idx) + '.jpg',
            #                 "resized_height": 300,
            #                 "resized_width": 300,
            #             },
            #             {"type": "text", "text": "How many people are there, what is each of them doing, break up the action of each person into head, torso, arms and legs."}, # "How many people are there, where is each of the person and what is each of them doing, what are they carrying?"},
            #         ],
            #     }
            # ]
            #
            # batch_of_messages.append(messages)
            #
            # if len(batch_of_messages) == batch_size:
            #     # Preparation for inference
            #     texts = [processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True) for messages in batch_of_messages]
            #     image_inputs, video_inputs = process_vision_info(batch_of_messages)
            #     inputs = processor(
            #         text=texts,
            #         images=image_inputs,
            #         videos=video_inputs,
            #         padding=True,
            #         return_tensors="pt",
            #     )
            #     inputs = inputs.to("cuda")
            #
            #     # Inference: Generation of the output
            #     generated_ids = model.generate(**inputs, max_new_tokens=512)
            #     generated_ids_trimmed = [
            #         out_ids[len(in_ids) :] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
            #     ]
            #     output_texts = processor.batch_decode(
            #         generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
            #     )
            #     print(output_texts)
            #
            #     for inner_batch_idx in range(len(batch_of_messages)):
            #         curr_video_results.append({
            #             "image": batch_of_messages[inner_batch_idx][0]['content'][0]['image'].split('.jpg')[0].split('dump/dump_')[1],
            #             "captions": output_texts[inner_batch_idx]
            #         })
            #
            #     batch_of_messages = []

    # joblib.dump(curr_video_results, os.path.join(dst_dir, video_name.split('.')[0] + '.pkl'))


















