import os
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------
# Positional Encoding
# --------------------
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        """
        d_model: 嵌入维度（本例为768）
        max_len: 序列最大长度
        """
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # (1, max_len, d_model)
        self.register_buffer('pe', pe)

    def forward(self, x):
        """
        x: (batch_size, seq_len, d_model)
        """
        return x + self.pe[:, :x.size(1)]


# ------------------------------
# Transformer Prediction Model
# ------------------------------
class TransformerPredictor(nn.Module):
    def __init__(self, d_model=768, nhead=8, num_layers=4, dropout=0.1):
        """
        d_model: 嵌入维度
        nhead: 注意力头数
        num_layers: Transformer编码器层数（8层）
        dropout: dropout比率
        """
        super(TransformerPredictor, self).__init__()
        self.d_model = d_model
        self.pos_encoder = PositionalEncoding(d_model)
        encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        # 输出全连接层，将池化后的向量映射到 d_model 维度
        self.fc = nn.Linear(d_model, d_model)
        self.mask = nn.Transformer.generate_square_subsequent_mask(4)


    def forward(self, src):
        """
        src: (batch_size, 4, 768)
        输出: (batch_size, 768)
        """
        # 添加位置编码
        src = self.pos_encoder(src)  # (batch_size, 4, 768)
        # Transformer要求输入形状为 (seq_len, batch_size, d_model)
        src = src.transpose(0, 1)  # (4, batch_size, 768)
        transformer_out = self.transformer_encoder(src, mask=self.mask)  # (4, batch_size, 768)
        transformer_out = transformer_out.transpose(0, 1)  # (batch_size, 4, 768)
        # 使用均值池化将4个token聚合成一个向量
        pooled = torch.mean(transformer_out, dim=1)  # (batch_size, 768)
        output = self.fc(pooled)  # (batch_size, 768)
        return output


# ----------------------
# Training and Checkpointing
# ----------------------
def train_model(model, optimizer, num_epochs=20, device='cuda', checkpoint_dir='checkpoints'):
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    start_epoch = 0
    # 尝试加载已有的最新checkpoint
    latest_ckpt = os.path.join(checkpoint_dir, "latest_checkpoint.pth")
    if os.path.exists(latest_ckpt):
        checkpoint = torch.load(latest_ckpt, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        print(f"Resumed training from epoch {start_epoch}")

    for epoch in range(start_epoch, num_epochs):
        model.train()
        batch_size = 32
        # 生成随机训练数据示例（实际应用中替换为真实数据）
        inputs = torch.randn(batch_size, 4, 768, device=device)
        targets = torch.randn(batch_size, 768, device=device)

        optimizer.zero_grad()
        outputs = model(inputs)  # (batch_size, 768)

        # 使用余弦相似度计算损失: loss = mean(1 - cosine_similarity)
        cos_sim = F.cosine_similarity(outputs, targets, dim=1)
        loss = torch.mean(1 - cos_sim)

        loss.backward()
        optimizer.step()

        print(f"Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}")

        # 每2个epoch保存一次checkpoint
        if (epoch + 1) % 2 == 0:
            ckpt_path = os.path.join(checkpoint_dir, f"checkpoint_epoch_{epoch + 1}.pth")
            checkpoint_data = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict()
            }
            torch.save(checkpoint_data, ckpt_path)
            # 更新latest_checkpoint以便下次恢复训练
            torch.save(checkpoint_data, latest_ckpt)
            print(f"Checkpoint saved at epoch {epoch + 1} -> {ckpt_path}")


# ----------------------
# Testing Function
# ----------------------
def test_model(model, device='cuda'):
    model.eval()
    with torch.no_grad():
        batch_size = 32
        # 生成随机测试数据示例（实际应用中替换为真实测试数据）
        test_inputs = torch.randn(batch_size, 4, 768, device=device)
        test_targets = torch.randn(batch_size, 768, device=device)
        outputs = model(test_inputs)
        cos_sim = F.cosine_similarity(outputs, test_targets, dim=1)
        loss = torch.mean(1 - cos_sim)
        print(f"Test Loss: {loss.item():.4f}")


# ----------------------
# Main Function
# ----------------------
def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TransformerPredictor(d_model=768, nhead=8, num_layers=8, dropout=0.1).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

    # 训练模型，自动加载已有checkpoint并从其继续训练
    train_model(model, optimizer, num_epochs=20, device=device, checkpoint_dir='checkpoints')

    # 在测试集上运行模型示例
    test_model(model, device=device)


if __name__ == "__main__":
    main()
