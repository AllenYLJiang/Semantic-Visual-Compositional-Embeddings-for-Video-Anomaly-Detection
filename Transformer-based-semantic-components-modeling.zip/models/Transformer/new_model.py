import torch
import torch.nn as nn
import torch.nn.functional as F
import math


# --------------------------
# Transformer模型定义
# --------------------------
class TransformerModel(nn.Module):
    def __init__(self, d_model=768, nhead=8, num_layers=4, vocab_size=768, dropout=0.1):
        """
        d_model: 输入（及隐藏）向量维度（768）
        nhead: 多头注意力头数（示例中设置为8）
        num_layers: Transformer编码器层数（4层）
        vocab_size: 预测输出类别数（768）
        dropout: dropout比例
        """
        super(TransformerModel, self).__init__()
        # 假设输入已经是768维向量，可直接进行位置编码
        self.pos_encoder = PositionalEncoding(d_model)
        encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        # 输出映射层，将 Transformer 的输出映射到 vocab_size（768）个类别
        self.fc_out = nn.Linear(d_model, vocab_size)

    def forward(self, src, src_mask=None):
        """
        src: (batch_size, seq_len, d_model)
        src_mask: (seq_len, seq_len) 的因果mask
        输出: (batch_size, seq_len, vocab_size)
        """
        # 添加位置编码
        src = self.pos_encoder(src)  # (batch_size, seq_len, d_model)
        # TransformerEncoder要求输入形状为 (seq_len, batch_size, d_model)
        src = src.transpose(0, 1)  # (seq_len, batch_size, d_model)
        enc_output = self.transformer_encoder(src, mask=src_mask)  # (seq_len, batch_size, d_model)
        enc_output = enc_output.transpose(0, 1)  # (batch_size, seq_len, d_model)
        logits = self.fc_out(enc_output)  # (batch_size, seq_len, vocab_size)
        return logits


# --------------------------
# 位置编码（Positional Encoding）
# --------------------------
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        """
        d_model: 嵌入维度
        max_len: 序列最大长度
        """
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # (1, max_len, d_model)
        self.register_buffer('pe', pe)

    def forward(self, x):
        """
        x: (batch_size, seq_len, d_model)
        """
        return x + self.pe[:, :x.size(1)]


# --------------------------
# 生成因果mask（下三角mask）
# --------------------------
def generate_causal_mask(seq_len, device):
    """
    生成形状为 (seq_len, seq_len) 的因果mask，使得每个位置只能关注当前位置及之前的token。
    """
    # 使用 nn.Transformer 内置方法
    mask = nn.Transformer.generate_square_subsequent_mask(seq_len).to(device)
    return mask


# --------------------------
# 主函数
# --------------------------
def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 超参数设置
    batch_size = 16
    seq_len = 10  # 示例序列长度
    d_model = 768
    vocab_size = 768
    num_layers = 4
    nhead = 8
    dropout = 0.1
    lr = 1e-4
    num_epochs = 5

    # 构建模型并移动到设备上
    model = TransformerModel(d_model=d_model, nhead=nhead, num_layers=num_layers,
                             vocab_size=vocab_size, dropout=dropout).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()  # 交叉熵损失

    for epoch in range(num_epochs):
        model.train()
        # 随机生成输入数据：假设输入已经是768维向量
        src = torch.randn(batch_size, seq_len, d_model, device=device)
        # 目标：生成随机整数作为类别标签，每个token的标签范围为[0, vocab_size)
        target = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)

        # 生成因果mask
        mask = generate_causal_mask(seq_len, device)

        optimizer.zero_grad()
        logits = model(src, src_mask=mask)  # logits: (batch_size, seq_len, vocab_size)
        # 将 logits reshape 为 (batch_size*seq_len, vocab_size)
        logits = logits.view(-1, vocab_size)
        # 将 target reshape 为 (batch_size*seq_len)
        target = target.view(-1)

        loss = criterion(logits, target)
        loss.backward()
        optimizer.step()

        print(f"Epoch {epoch + 1}/{num_epochs}, Loss: {loss.item():.4f}")


if __name__ == "__main__":
    main()
