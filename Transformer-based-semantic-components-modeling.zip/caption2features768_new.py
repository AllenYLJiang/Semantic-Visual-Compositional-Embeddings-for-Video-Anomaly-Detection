import json
import joblib
import os
import re
import torch
import clip
import numpy as np




def readfile(filepath):
    if filepath.endswith('pkl'):
        file = joblib.load(filepath)
    elif filepath.endswith('json'):
        file = json.load(open(filepath, 'r'))
    else:
        print(f"input is {filepath.split('.')[-1]} file, which is unsupported!")
        return -1
    return file

if __name__ == '__main__':
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/32", device)
    # model, vis_processors, text_processors = load_model_and_preprocess("blip2_image_text_matching", "pretrain",                                                                  device=device, is_eval=True)
    root_path = f"E:\\Shanghaitech_How many subjects are there, decompose each subject into four semantic components and provide an overall description about each subject. Describe each subject in the format of template\\test"
    root_save_path = f"E:\\pyproject1\\STG-NF\\result_768features"
    for filename in os.listdir(root_path):
        print(filename)
        input_file = readfile(os.path.join(root_path, filename))
        output_file = {}
        pre_dict_key = []
        save_dict_values = []
        for frame_dict in input_file:
            save_dict_key = frame_dict['image'].split('Crop_')[0]
            caption = frame_dict['captions']
            # keywords = ["Head", "Torso", "Arms", "Legs", "Overall Body"]
            keywords = ["Component 1", "Component 2", "Component 3", "Component 4", "Overall"]
            empty_keyword = 'no people'
            if re.search(empty_keyword, caption):
                continue  # 对应块没有检测到人
            else:
                person_blocks = caption.strip().split("\n\n")
            # 遍历关键词，提取对应的描述部分
                for person in person_blocks:
                    sentences = []
                    for keyword in keywords:
                        # 使用正则表达式查找每个关键词及其后面的描述部分
                        match = re.search(rf"{keyword}(.*?)(?=\n|$)", caption, re.DOTALL)
                        if match:
                            raw_sentence = match.group(1).strip()
                            split_sentence = raw_sentence.split(" ")
                            if len(split_sentence) >= 50:
                                split_sentence = split_sentence[:50]
                            for idx in range(len(split_sentence)):
                                if len(split_sentence[idx]) >= 20:
                                    split_sentence[idx] = split_sentence[idx][:20]
                            raw_sentence = ' '.join(split_sentence)
                            sentences.append(raw_sentence)
                    if not sentences:
                        continue
                    sentence_input = clip.tokenize(sentences).to(device)  # 对文本进行tokenization并移动到设备上
                    with torch.no_grad():
                        sentence_features = model.encode_text(sentence_input).cpu().numpy()
                    sentence_features = np.concatenate([sentence_features, sentence_features[:, :256]], axis=1)# 获取文本的嵌入
                    if not pre_dict_key:
                        pre_dict_key = save_dict_key
                        save_dict_values.append(sentence_features)
                        continue
                    if save_dict_key == pre_dict_key:
                        save_dict_values.append(sentence_features)
                    else:
                        output_file.update({pre_dict_key: save_dict_values})
                        save_dict_values = []
                        pre_dict_key = save_dict_key
        joblib.dump(output_file, os.path.join(root_save_path, filename.split('.')[0]+'.pkl'))

